"use client"

import { useMemo, useState } from "react"
import { Plus, Pencil, Trash2, Receipt, CalendarDays, PiggyBank } from "lucide-react"
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip, Legend } from "recharts"
import { db, type Expense } from "@/lib/db"
import { useExpenses, useSettings, updateSettings } from "@/lib/hooks"
import { formatINR, formatPercent } from "@/lib/format"
import { PageHeader, SectionCard, StatCard, CHART_COLORS } from "@/components/finance/primitives"
import { MoneyTooltip } from "@/components/finance/chart-tooltip"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { toast } from "sonner"

const empty: Omit<Expense, "id"> = { category: "", monthly: 0 }

export default function ExpensesPage() {
  const expenses = useExpenses()
  const settings = useSettings()
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Expense | null>(null)
  const [form, setForm] = useState<Omit<Expense, "id">>(empty)

  const monthlyTotal = expenses.reduce((a, e) => a + e.monthly, 0)
  const annualTotal = monthlyTotal * 12
  const monthlySavings = settings.monthlyIncome - monthlyTotal
  const savingsRate = settings.monthlyIncome > 0 ? (monthlySavings / settings.monthlyIncome) * 100 : 0

  const breakdown = useMemo(
    () => expenses.map((e) => ({ name: e.category, value: e.monthly })).sort((a, b) => b.value - a.value),
    [expenses],
  )

  function openAdd() {
    setEditing(null)
    setForm(empty)
    setOpen(true)
  }

  function openEdit(e: Expense) {
    setEditing(e)
    const { id, ...rest } = e
    setForm(rest)
    setOpen(true)
  }

  async function save() {
    if (!form.category.trim()) {
      toast.error("Category is required")
      return
    }
    if (editing?.id) {
      await db.expenses.update(editing.id, form)
      toast.success("Expense updated")
    } else {
      await db.expenses.add(form)
      toast.success("Expense added")
    }
    setOpen(false)
  }

  async function remove(e: Expense) {
    if (e.id) {
      await db.expenses.delete(e.id)
      toast.success("Expense deleted")
    }
  }

  return (
    <div>
      <PageHeader title="Expenses" description="Track spending categories and your savings rate.">
        <Button onClick={openAdd}>
          <Plus className="size-4" /> Add Category
        </Button>
      </PageHeader>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Monthly Expenses" value={formatINR(monthlyTotal, { compact: true })} icon={Receipt} />
        <StatCard label="Annual Expenses" value={formatINR(annualTotal, { compact: true })} icon={CalendarDays} accent="text-chart-3" />
        <StatCard label="Monthly Savings" value={formatINR(monthlySavings, { compact: true })} icon={PiggyBank} accent={monthlySavings >= 0 ? "text-chart-1" : "text-destructive"} />
        <StatCard label="Savings Rate" value={formatPercent(savingsRate)} icon={PiggyBank} accent="text-chart-4" />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-5">
        <SectionCard title="Expense Breakdown" description="Share of monthly spending" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={breakdown} dataKey="value" nameKey="name" innerRadius={55} outerRadius={95} paddingAngle={2}>
                {breakdown.map((_, i) => (
                  <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} stroke="var(--background)" strokeWidth={2} />
                ))}
              </Pie>
              <Tooltip content={<MoneyTooltip />} />
              <Legend iconType="circle" formatter={(v) => <span className="text-xs text-muted-foreground">{v}</span>} />
            </PieChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard
          title="Spending Categories"
          description={`${expenses.length} categories`}
          className="lg:col-span-3"
          action={
            <div className="rounded-lg bg-accent px-3 py-1.5 text-right">
              <p className="text-xs text-accent-foreground">Monthly Income</p>
              <Input
                type="number"
                value={settings.monthlyIncome}
                onChange={(e) => updateSettings({ monthlyIncome: Number(e.target.value) })}
                className="h-7 w-32 border-0 bg-transparent p-0 text-right text-sm font-semibold focus-visible:ring-0"
              />
            </div>
          }
        >
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Category</TableHead>
                  <TableHead className="text-right">Monthly</TableHead>
                  <TableHead className="text-right">Annual</TableHead>
                  <TableHead className="text-right">% of Total</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {expenses.map((e) => (
                  <TableRow key={e.id}>
                    <TableCell className="font-medium">{e.category}</TableCell>
                    <TableCell className="text-right tabular-nums">{formatINR(e.monthly)}</TableCell>
                    <TableCell className="text-right tabular-nums text-muted-foreground">{formatINR(e.monthly * 12)}</TableCell>
                    <TableCell className="text-right tabular-nums">
                      {monthlyTotal ? formatPercent((e.monthly / monthlyTotal) * 100) : "0%"}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button variant="ghost" size="icon" onClick={() => openEdit(e)} aria-label="Edit">
                          <Pencil className="size-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => remove(e)} aria-label="Delete">
                          <Trash2 className="size-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {expenses.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="py-8 text-center text-muted-foreground">
                      No expense categories yet.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
              <TableFooter>
                <TableRow>
                  <TableCell className="font-semibold">Total</TableCell>
                  <TableCell className="text-right font-semibold tabular-nums">{formatINR(monthlyTotal)}</TableCell>
                  <TableCell className="text-right font-semibold tabular-nums">{formatINR(annualTotal)}</TableCell>
                  <TableCell className="text-right font-semibold">100%</TableCell>
                  <TableCell />
                </TableRow>
              </TableFooter>
            </Table>
          </div>
        </SectionCard>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Category" : "Add Category"}</DialogTitle>
            <DialogDescription>Add a monthly spending category.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-2">
              <Label htmlFor="cat">Category</Label>
              <Input id="cat" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="e.g. Groceries & Food" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="amount">Monthly Amount (₹)</Label>
              <Input id="amount" type="number" value={form.monthly || ""} onChange={(e) => setForm({ ...form, monthly: Number(e.target.value) })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={save}>{editing ? "Save Changes" : "Add Category"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
