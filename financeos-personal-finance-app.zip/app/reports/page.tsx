"use client"

import { useMemo } from "react"
import { CameraIcon, Trash2, TrendingUp, Wallet, PiggyBank } from "lucide-react"
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Legend,
} from "recharts"
import { db } from "@/lib/db"
import { useExpenses, useInvestments, useSettings, useSnapshots } from "@/lib/hooks"
import { formatINR, formatMonth } from "@/lib/format"
import { PageHeader, SectionCard, StatCard } from "@/components/finance/primitives"
import { MoneyTooltip } from "@/components/finance/chart-tooltip"
import { Button } from "@/components/ui/button"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { toast } from "sonner"

export default function ReportsPage() {
  const snapshots = useSnapshots()
  const investments = useInvestments()
  const expenses = useExpenses()
  const settings = useSettings()

  const investmentsTotal = investments.reduce((a, i) => a + i.current, 0)
  const monthlyExpenses = expenses.reduce((a, e) => a + e.monthly, 0)
  const netWorth = investmentsTotal + settings.pfBalance + settings.emergencyFund
  const monthlySavings = settings.monthlyIncome - monthlyExpenses

  const chartData = useMemo(
    () =>
      snapshots.map((s) => ({
        month: formatMonth(s.month),
        "Net Worth": s.netWorth,
        Investments: s.investments,
        Savings: s.savings,
        Expenses: s.expenses,
      })),
    [snapshots],
  )

  const latest = snapshots[snapshots.length - 1]
  const first = snapshots[0]
  const nwGrowth = first && latest ? ((latest.netWorth - first.netWorth) / first.netWorth) * 100 : 0

  async function captureSnapshot() {
    const month = new Date().toISOString().slice(0, 7)
    const existing = await db.snapshots.where("month").equals(month).first()
    const payload = {
      month,
      netWorth,
      investments: investmentsTotal,
      savings: Math.max(0, monthlySavings),
      expenses: monthlyExpenses,
    }
    if (existing?.id) {
      await db.snapshots.update(existing.id, payload)
      toast.success(`Snapshot for ${formatMonth(month)} updated`)
    } else {
      await db.snapshots.add(payload)
      toast.success(`Snapshot for ${formatMonth(month)} captured`)
    }
  }

  async function removeSnapshot(id?: number) {
    if (id) {
      await db.snapshots.delete(id)
      toast.success("Snapshot deleted")
    }
  }

  return (
    <div>
      <PageHeader title="Reports" description="Monthly snapshots and historical trends.">
        <Button onClick={captureSnapshot}>
          <CameraIcon className="size-4" /> Capture Snapshot
        </Button>
      </PageHeader>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Current Net Worth" value={formatINR(netWorth, { compact: true })} icon={Wallet} />
        <StatCard label="Net Worth Growth" value={`${nwGrowth >= 0 ? "+" : ""}${nwGrowth.toFixed(1)}%`} icon={TrendingUp} accent={nwGrowth >= 0 ? "text-chart-1" : "text-destructive"} hint="since first snapshot" />
        <StatCard label="Snapshots Logged" value={`${snapshots.length}`} icon={CameraIcon} accent="text-chart-3" />
        <StatCard label="Avg Monthly Savings" value={formatINR(snapshots.length ? snapshots.reduce((a, s) => a + s.savings, 0) / snapshots.length : 0, { compact: true })} icon={PiggyBank} accent="text-chart-4" />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <SectionCard title="Net Worth History" description="Net worth and investments over time">
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={chartData} margin={{ left: -4, right: 8, top: 8 }}>
              <defs>
                <linearGradient id="rnw" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={11} stroke="var(--muted-foreground)" />
              <YAxis tickFormatter={(v) => formatINR(v, { compact: true })} tickLine={false} axisLine={false} fontSize={11} stroke="var(--muted-foreground)" width={56} />
              <Tooltip content={<MoneyTooltip />} />
              <Legend iconType="circle" formatter={(v) => <span className="text-xs text-muted-foreground">{v}</span>} />
              <Area type="monotone" dataKey="Net Worth" stroke="var(--chart-1)" strokeWidth={2} fill="url(#rnw)" />
              <Line type="monotone" dataKey="Investments" stroke="var(--chart-3)" strokeWidth={2} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard title="Savings History" description="Monthly savings vs expenses">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData} margin={{ left: -4, right: 8, top: 8 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={11} stroke="var(--muted-foreground)" />
              <YAxis tickFormatter={(v) => formatINR(v, { compact: true })} tickLine={false} axisLine={false} fontSize={11} stroke="var(--muted-foreground)" width={56} />
              <Tooltip content={<MoneyTooltip />} cursor={{ fill: "var(--accent)", opacity: 0.4 }} />
              <Legend iconType="circle" formatter={(v) => <span className="text-xs text-muted-foreground">{v}</span>} />
              <Bar dataKey="Savings" fill="var(--chart-1)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Expenses" fill="var(--chart-5)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>
      </div>

      <SectionCard title="Monthly Snapshots" description={`${snapshots.length} records`} className="mt-6">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Month</TableHead>
                <TableHead className="text-right">Net Worth</TableHead>
                <TableHead className="text-right">Investments</TableHead>
                <TableHead className="text-right">Savings</TableHead>
                <TableHead className="text-right">Expenses</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...snapshots].reverse().map((s) => (
                <TableRow key={s.id}>
                  <TableCell className="font-medium">{formatMonth(s.month)}</TableCell>
                  <TableCell className="text-right font-medium tabular-nums">{formatINR(s.netWorth)}</TableCell>
                  <TableCell className="text-right tabular-nums">{formatINR(s.investments)}</TableCell>
                  <TableCell className="text-right tabular-nums text-chart-1">{formatINR(s.savings)}</TableCell>
                  <TableCell className="text-right tabular-nums text-muted-foreground">{formatINR(s.expenses)}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => removeSnapshot(s.id)} aria-label="Delete">
                      <Trash2 className="size-4 text-destructive" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {snapshots.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="py-8 text-center text-muted-foreground">
                    No snapshots yet. Capture one to start tracking history.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </SectionCard>
    </div>
  )
}
