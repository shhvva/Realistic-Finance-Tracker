"use client"

import { useMemo } from "react"
import {
  Wallet,
  TrendingUp,
  ShieldCheck,
  PiggyBank,
  PercentCircle,
} from "lucide-react"
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Legend,
} from "recharts"
import { CATEGORY_LABELS, type InvestmentCategory } from "@/lib/db"
import { useExpenses, useGoals, useInvestments, useSettings, useSnapshots } from "@/lib/hooks"
import { formatINR, formatMonth, formatPercent } from "@/lib/format"
import { PageHeader, StatCard, SectionCard, CHART_COLORS } from "@/components/finance/primitives"
import { MoneyTooltip } from "@/components/finance/chart-tooltip"

export default function DashboardPage() {
  const investments = useInvestments()
  const goals = useGoals()
  const expenses = useExpenses()
  const snapshots = useSnapshots()
  const settings = useSettings()

  const investmentsTotal = investments.reduce((a, i) => a + i.current, 0)
  const monthlyExpenses = expenses.reduce((a, e) => a + e.monthly, 0)
  const netWorth = investmentsTotal + settings.pfBalance + settings.emergencyFund
  const monthlySavings = settings.monthlyIncome - monthlyExpenses
  const savingsRate = settings.monthlyIncome > 0 ? (monthlySavings / settings.monthlyIncome) * 100 : 0

  const allocation = useMemo(() => {
    const map = new Map<InvestmentCategory, number>()
    for (const inv of investments) map.set(inv.category, (map.get(inv.category) ?? 0) + inv.current)
    return Array.from(map.entries()).map(([cat, value]) => ({
      name: CATEGORY_LABELS[cat],
      value,
    }))
  }, [investments])

  const marketCap = useMemo(() => {
    const order: InvestmentCategory[] = ["large", "flexi", "mid", "small"]
    return order.map((cat) => ({
      name: CATEGORY_LABELS[cat],
      value: investments.filter((i) => i.category === cat).reduce((a, i) => a + i.current, 0),
    }))
  }, [investments])

  const goalProgress = useMemo(
    () =>
      goals.map((g) => ({
        name: g.name,
        current: g.current,
        remaining: Math.max(0, g.target - g.current),
      })),
    [goals],
  )

  const cashFlow = [
    { name: "Income", value: settings.monthlyIncome },
    { name: "Expenses", value: monthlyExpenses },
    { name: "Savings", value: Math.max(0, monthlySavings) },
  ]

  const netWorthHistory = snapshots.map((s) => ({
    month: formatMonth(s.month),
    netWorth: s.netWorth,
    investments: s.investments,
  }))

  return (
    <div>
      <PageHeader title="Dashboard" description="A complete snapshot of your financial health." />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard label="Net Worth" value={formatINR(netWorth, { compact: true })} icon={Wallet} hint="Investments + PF + Emergency" />
        <StatCard label="Investments" value={formatINR(investmentsTotal, { compact: true })} icon={TrendingUp} accent="text-chart-1" hint={`${investments.length} funds`} />
        <StatCard label="Emergency Fund" value={formatINR(settings.emergencyFund, { compact: true })} icon={ShieldCheck} accent="text-chart-2" hint={`${(settings.emergencyFund / (monthlyExpenses || 1)).toFixed(1)} months cover`} />
        <StatCard label="PF Balance" value={formatINR(settings.pfBalance, { compact: true })} icon={PiggyBank} accent="text-chart-3" hint={`+${formatINR(settings.pfMonthly, { compact: true })}/mo`} />
        <StatCard label="Savings Rate" value={formatPercent(savingsRate)} icon={PercentCircle} accent="text-chart-4" hint={`${formatINR(monthlySavings, { compact: true })}/mo saved`} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <SectionCard title="Net Worth History" description="Trend across recent months">
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={netWorthHistory} margin={{ left: -10, right: 8, top: 8 }}>
              <defs>
                <linearGradient id="nw" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="inv" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--chart-3)" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="var(--chart-3)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="month" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
              <YAxis tickFormatter={(v) => formatINR(v, { compact: true })} tickLine={false} axisLine={false} fontSize={11} stroke="var(--muted-foreground)" width={60} />
              <Tooltip content={<MoneyTooltip />} />
              <Area type="monotone" dataKey="netWorth" name="Net Worth" stroke="var(--chart-1)" strokeWidth={2} fill="url(#nw)" />
              <Area type="monotone" dataKey="investments" name="Investments" stroke="var(--chart-3)" strokeWidth={2} fill="url(#inv)" />
            </AreaChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard title="Monthly Cash Flow" description="Income vs expenses vs savings">
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={cashFlow} margin={{ left: -10, right: 8, top: 8 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
              <YAxis tickFormatter={(v) => formatINR(v, { compact: true })} tickLine={false} axisLine={false} fontSize={11} stroke="var(--muted-foreground)" width={60} />
              <Tooltip content={<MoneyTooltip />} cursor={{ fill: "var(--accent)", opacity: 0.4 }} />
              <Bar dataKey="value" name="Amount" radius={[6, 6, 0, 0]}>
                {cashFlow.map((_, i) => (
                  <Cell key={i} fill={CHART_COLORS[i]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard title="Asset Allocation" description="Current value by category">
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={allocation} dataKey="value" nameKey="name" innerRadius={60} outerRadius={100} paddingAngle={2}>
                {allocation.map((_, i) => (
                  <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} stroke="var(--background)" strokeWidth={2} />
                ))}
              </Pie>
              <Tooltip content={<MoneyTooltip />} />
              <Legend iconType="circle" formatter={(v) => <span className="text-xs text-muted-foreground">{v}</span>} />
            </PieChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard title="Market Cap Allocation" description="Equity exposure by cap size">
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={marketCap} layout="vertical" margin={{ left: 10, right: 16 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
              <XAxis type="number" tickFormatter={(v) => formatINR(v, { compact: true })} tickLine={false} axisLine={false} fontSize={11} stroke="var(--muted-foreground)" />
              <YAxis type="category" dataKey="name" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" width={70} />
              <Tooltip content={<MoneyTooltip />} cursor={{ fill: "var(--accent)", opacity: 0.4 }} />
              <Bar dataKey="value" name="Value" radius={[0, 6, 6, 0]}>
                {marketCap.map((_, i) => (
                  <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard title="Goal Progress" description="Saved vs remaining per goal" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={goalProgress} margin={{ left: -10, right: 8, top: 8 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="name" tickLine={false} axisLine={false} fontSize={12} stroke="var(--muted-foreground)" />
              <YAxis tickFormatter={(v) => formatINR(v, { compact: true })} tickLine={false} axisLine={false} fontSize={11} stroke="var(--muted-foreground)" width={60} />
              <Tooltip content={<MoneyTooltip />} cursor={{ fill: "var(--accent)", opacity: 0.4 }} />
              <Legend iconType="circle" formatter={(v) => <span className="text-xs text-muted-foreground">{v}</span>} />
              <Bar dataKey="current" name="Saved" stackId="g" fill="var(--chart-1)" />
              <Bar dataKey="remaining" name="Remaining" stackId="g" fill="var(--muted)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>
      </div>
    </div>
  )
}
