import type { Settings, WithdrawalEvent } from "./db"

export interface ProjectionYear {
  age: number
  year: number
  corpus: number
  realCorpus: number // inflation adjusted
  contributions: number // cumulative contributions
  returns: number // cumulative returns
}

export function projectRetirement(s: Settings): ProjectionYear[] {
  const years: ProjectionYear[] = []
  const r = s.expectedReturn / 100
  const infl = s.inflation / 100
  const stepUp = s.stepUp / 100
  const startYear = new Date().getFullYear()

  let corpus = 0
  let annualInvest = s.annualInvestment
  let cumulativeContrib = 0

  const withdrawalsByAge = new Map<number, number>()
  for (const w of s.withdrawals) {
    withdrawalsByAge.set(w.age, (withdrawalsByAge.get(w.age) ?? 0) + w.amount)
  }

  for (let age = s.currentAge; age <= s.retirementAge; age++) {
    // grow existing corpus
    corpus = corpus * (1 + r)
    // add this year's contribution
    corpus += annualInvest
    cumulativeContrib += annualInvest
    // apply withdrawal events
    const w = withdrawalsByAge.get(age)
    if (w) corpus -= w

    const elapsed = age - s.currentAge
    const realCorpus = corpus / Math.pow(1 + infl, elapsed)

    years.push({
      age,
      year: startYear + elapsed,
      corpus: Math.max(0, Math.round(corpus)),
      realCorpus: Math.max(0, Math.round(realCorpus)),
      contributions: Math.round(cumulativeContrib),
      returns: Math.max(0, Math.round(corpus - cumulativeContrib + sumWithdrawalsUpTo(s.withdrawals, age))),
    })

    annualInvest = annualInvest * (1 + stepUp)
  }

  return years
}

function sumWithdrawalsUpTo(withdrawals: WithdrawalEvent[], age: number): number {
  return withdrawals.filter((w) => w.age <= age).reduce((a, w) => a + w.amount, 0)
}

export interface PFYear {
  year: number
  balance: number
  contributed: number
  interest: number
}

export function projectPF(balance: number, monthly: number, rate: number, years = 25): PFYear[] {
  const out: PFYear[] = []
  const annualRate = rate / 100
  const startYear = new Date().getFullYear()
  let bal = balance
  let totalContrib = balance

  for (let i = 0; i <= years; i++) {
    if (i > 0) {
      // monthly contributions for the year + interest on running balance
      const yearlyContrib = monthly * 12
      bal = bal * (1 + annualRate) + yearlyContrib * (1 + annualRate / 2)
      totalContrib += yearlyContrib
    }
    out.push({
      year: startYear + i,
      balance: Math.round(bal),
      contributed: Math.round(totalContrib),
      interest: Math.round(bal - totalContrib),
    })
  }
  return out
}

export function retirementCorpusTarget(annualExpenses: number, inflation: number, yearsToRetire: number): number {
  // 25x rule on inflation-adjusted expenses at retirement
  const futureExpenses = annualExpenses * Math.pow(1 + inflation / 100, yearsToRetire)
  return futureExpenses * 25
}
