import Dexie, { type Table } from "dexie"

export type InvestmentCategory = "large" | "flexi" | "mid" | "small" | "gold" | "debt"

export interface Investment {
  id?: number
  name: string
  category: InvestmentCategory
  sip: number // monthly SIP amount
  invested: number // total invested value
  current: number // current value
  xirr: number // percentage
}

export interface Goal {
  id?: number
  name: string
  current: number
  target: number
  monthly: number // monthly contribution
  dueDate: string // ISO date
}

export interface Expense {
  id?: number
  category: string
  monthly: number
}

export interface Snapshot {
  id?: number
  month: string // e.g. "2026-01"
  netWorth: number
  investments: number
  savings: number
  expenses: number
}

export interface WithdrawalEvent {
  id: string
  age: number
  amount: number
  label: string
}

export interface Settings {
  id: string // always "app"
  monthlyIncome: number
  emergencyFund: number
  // PF
  pfBalance: number
  pfMonthly: number
  epfRate: number
  // Projections
  currentAge: number
  retirementAge: number
  expectedReturn: number
  inflation: number
  annualInvestment: number
  stepUp: number
  annualExpenses: number
  withdrawals: WithdrawalEvent[]
}

export const CATEGORY_LABELS: Record<InvestmentCategory, string> = {
  large: "Large Cap",
  flexi: "Flexi Cap",
  mid: "Mid Cap",
  small: "Small Cap",
  gold: "Gold",
  debt: "Debt",
}

class FinanceDB extends Dexie {
  investments!: Table<Investment, number>
  goals!: Table<Goal, number>
  expenses!: Table<Expense, number>
  snapshots!: Table<Snapshot, number>
  settings!: Table<Settings, string>

  constructor() {
    super("financeos")
    this.version(1).stores({
      investments: "++id, name, category",
      goals: "++id, name, dueDate",
      expenses: "++id, category",
      snapshots: "++id, month",
      settings: "id",
    })
  }
}

export const db = new FinanceDB()

export const DEFAULT_SETTINGS: Settings = {
  id: "app",
  monthlyIncome: 220000,
  emergencyFund: 1200000,
  pfBalance: 1850000,
  pfMonthly: 21600,
  epfRate: 8.25,
  currentAge: 32,
  retirementAge: 55,
  expectedReturn: 12,
  inflation: 6,
  annualInvestment: 720000,
  stepUp: 10,
  annualExpenses: 1200000,
  withdrawals: [
    { id: "w1", age: 40, amount: 2500000, label: "Home down payment" },
    { id: "w2", age: 45, amount: 1500000, label: "Child education" },
  ],
}

let seeded = false

export async function ensureSeed() {
  if (seeded) return
  seeded = true

  const existing = await db.settings.get("app")
  if (!existing) {
    await db.settings.put(DEFAULT_SETTINGS)
  }

  const invCount = await db.investments.count()
  if (invCount === 0) {
    await db.investments.bulkAdd([
      { name: "Axis Bluechip Fund", category: "large", sip: 15000, invested: 540000, current: 712000, xirr: 14.2 },
      { name: "Parag Parikh Flexi Cap", category: "flexi", sip: 20000, invested: 720000, current: 985000, xirr: 16.8 },
      { name: "Kotak Emerging Equity", category: "mid", sip: 12000, invested: 432000, current: 596000, xirr: 18.1 },
      { name: "Nippon Small Cap", category: "small", sip: 10000, invested: 360000, current: 548000, xirr: 22.4 },
      { name: "SBI Gold Fund", category: "gold", sip: 5000, invested: 180000, current: 214000, xirr: 11.3 },
      { name: "HDFC Corporate Bond", category: "debt", sip: 8000, invested: 288000, current: 312000, xirr: 7.2 },
    ])
  }

  const goalCount = await db.goals.count()
  if (goalCount === 0) {
    await db.goals.bulkAdd([
      { name: "Emergency Fund", current: 1200000, target: 1500000, monthly: 25000, dueDate: "2026-12-31" },
      { name: "Home Purchase", current: 2800000, target: 8000000, monthly: 60000, dueDate: "2029-06-30" },
      { name: "Child Education", current: 650000, target: 5000000, monthly: 30000, dueDate: "2035-04-30" },
      { name: "Dream Vacation", current: 180000, target: 400000, monthly: 15000, dueDate: "2027-03-31" },
    ])
  }

  const expCount = await db.expenses.count()
  if (expCount === 0) {
    await db.expenses.bulkAdd([
      { category: "Housing & Rent", monthly: 45000 },
      { category: "Groceries & Food", monthly: 22000 },
      { category: "Transportation", monthly: 12000 },
      { category: "Utilities & Bills", monthly: 9000 },
      { category: "Healthcare", monthly: 7000 },
      { category: "Entertainment", monthly: 11000 },
      { category: "Insurance", monthly: 8500 },
    ])
  }

  const snapCount = await db.snapshots.count()
  if (snapCount === 0) {
    const months = ["2025-08", "2025-09", "2025-10", "2025-11", "2025-12", "2026-01"]
    let nw = 5800000
    let inv = 2900000
    const rows: Snapshot[] = months.map((month, i) => {
      nw += 320000 + i * 28000
      inv += 180000 + i * 12000
      return {
        month,
        netWorth: nw,
        investments: inv,
        savings: 95000 + i * 6000,
        expenses: 114500,
      }
    })
    await db.snapshots.bulkAdd(rows)
  }
}
