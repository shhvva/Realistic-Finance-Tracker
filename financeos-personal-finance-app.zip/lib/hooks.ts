"use client"

import { useLiveQuery } from "dexie-react-hooks"
import { db, DEFAULT_SETTINGS, type Settings } from "./db"

export function useInvestments() {
  return useLiveQuery(() => db.investments.toArray(), [], [])
}

export function useGoals() {
  return useLiveQuery(() => db.goals.toArray(), [], [])
}

export function useExpenses() {
  return useLiveQuery(() => db.expenses.toArray(), [], [])
}

export function useSnapshots() {
  return useLiveQuery(async () => {
    const rows = await db.snapshots.toArray()
    return rows.sort((a, b) => a.month.localeCompare(b.month))
  }, [], [])
}

export function useSettings(): Settings {
  return useLiveQuery(() => db.settings.get("app"), [], DEFAULT_SETTINGS) ?? DEFAULT_SETTINGS
}

export async function updateSettings(patch: Partial<Settings>) {
  const current = (await db.settings.get("app")) ?? DEFAULT_SETTINGS
  await db.settings.put({ ...current, ...patch, id: "app" })
}
